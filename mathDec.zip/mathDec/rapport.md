
#1 Introduction généralités et notations

# 2 Méthode MGL

## 2.1 Propriétés de la méthode

## 2.2 Description détaillée de la méthode optionnel

## 2.3 Exemples

# 3 Algorithme

## 3.1 Description de l’algorithme

## 3.2 Preuve de l’algorithme
